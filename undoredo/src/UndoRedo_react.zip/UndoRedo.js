import React, { useState, useRef } from 'react';
import './UndoRedo.css'

export default function UndoRedo() {
    
    const inputRef = useRef(null);
    const [inputNumber, setInputNumber] = useState();
    const [resultNumber, setResultNumber] = useState([0]);
    const [index, setIndex] = useState(0);
    
    const buttonFunction = {
        undoButton: () => {
            setIndex(prevState => prevState - 1);
        },
        addButton: () => {
            if(inputRef.current.value === '') {
                inputRef.current.focus();
                return;
            }
            let array = resultNumber.slice(0, index + 1);
            setResultNumber([...array, resultNumber[index] + inputNumber]);
            setIndex(prevState => prevState + 1);
            setInputNumber(0);
            inputRef.current.value = '';    
            inputRef.current.focus();
        },
        subButton: () => {
            if(inputRef.current.value === '') {
                inputRef.current.focus();
                return;
            }
            let array = resultNumber.slice(0, index + 1);
            setResultNumber([...array, resultNumber[index] - inputNumber]);
            setIndex(prevState => prevState + 1);
            setInputNumber(0)
            inputRef.current.value = '';
            inputRef.current.focus();
        },
        redoButton: () => {
            setIndex(prevState => prevState + 1);
        },  
    }

    return (
        <div className={"container"}>
            <div id={"valuebox"} className={"counter"} value={resultNumber[index]}>{resultNumber[index]}</div>
            <input ref={inputRef} id={"inputbox"} className={"input"} onChange={(e) => setInputNumber(Number(e.target.value))}/>
            <div className={"btnGroup"}>
                <button id={"undoButton"} className={"btn"} onClick={buttonFunction.undoButton} disabled={index > 0 ? false : true}>Undo</button>
                <button id={"addButton"} className={"btn"} onClick={buttonFunction.addButton}>+</button>
                <button id={"subButton"} className={"btn"} onClick={buttonFunction.subButton}>-</button>
                <button id={"redoButton"} className={"btn"} onClick={buttonFunction.redoButton} disabled={index === resultNumber.length - 1 ? true : false}>Redo</button>
            </div>
        </div>
    )
}