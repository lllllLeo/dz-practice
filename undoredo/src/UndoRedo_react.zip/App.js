import React from 'react';
import UndoRedo from './UndoRedo';

export default function App() {
  return (
    <div className='App'>
      <UndoRedo />
    </div>
  );
}

