import React, { useState, useRef } from 'react';
import './UndoRedo.css'

export default function UndoRedo() {

    const inputRef = useRef(null); // 함수가 반환되고 render가 될때까지 참조가 설정되지 않으므로 null로
    const [inputNumber, setInputNumber] = useState();
    const [resultNumber, setResultNumber] = useState([0]);
    const [index, setIndex] = useState(0);

    // TODO: onChange 개선 splice
    const buttonFunction = {
        undoButton: (e) => {
            setIndex(prevState => prevState - 1);
            console.log('undoButton index: ', index);

        },
        addButton: (e) => {
            if(inputRef.current.value === '') {
                return;
            }
            // setResultNumber([...resultNumber, resultNumber[index] + inputNumber]);
            let array = [0];
            array = resultNumber.slice(1);
            console.log(resultNumber);
            console.log(array);
            console.log(resultNumber[index] + inputNumber);
            setResultNumber([...array, resultNumber[index] + inputNumber]);
            setIndex(prevState => prevState + 1);
            setInputNumber(0);

            inputRef.current.value = '';
            inputRef.current.focus();
        },
        subButton: (e) => {
            if(inputRef.current.value === '') {
                return;
            }
            console.log('inputNumber: ', inputNumber);
            console.log('resultNumber[index]: ', resultNumber[index]);
            let array = resultNumber.slice(index + 1);
            console.log(array);
            setResultNumber([...array, resultNumber[index] - inputNumber]);
            setIndex(prevState => prevState + 1);
            setInputNumber(0)
            console.log('index: ', index);
            console.log('resultNumber[index]: ', resultNumber[index]);
            console.log('resultNumber: ', resultNumber);
            inputRef.current.value = '';
            inputRef.current.focus();
        },
        redoButton: (e) => {
            setIndex(prevState => prevState + 1);
        },  
    }

    // console.log('inputNumber: ', inputNumber);
    // console.log('resultNumber: ', resultNumber);
    console.log('index: ', index);
    console.log('resultNumber[index]: ', resultNumber[index]);
    console.log('resultNumber: ', resultNumber);
    // console.log('resultNumber[index + 1]: ', resultNumber[index + 1]);
    // console.log('resultNumber.length: ', resultNumber.length);
    return (
        <div className={"container"}>
            <div id={"valuebox"} className={"counter"} value={resultNumber[index]}>{resultNumber[index]}</div>
            {/* <input id={"inputbox"} className={"input"} onChange={handleChange}/> */}
            <input ref={inputRef} id={"inputbox"} className={"input"} onChange={(e) => setInputNumber(Number(e.target.value))}/>
            <div className={"btnGroup"}>
                <button id={"undoButton"} className={"btn"} onClick={buttonFunction.undoButton} disabled={index > 0 ? false : true}>Undo</button>
                <button id={"addButton"} className={"btn"} onClick={buttonFunction.addButton}>+</button>
                <button id={"subButton"} className={"btn"} onClick={buttonFunction.subButton}>-</button>
                <button id={"redoButton"} className={"btn"} onClick={buttonFunction.redoButton} disabled={index === resultNumber.length - 1 ? true : false}>Redo</button>
            </div>
        </div>
    )
}